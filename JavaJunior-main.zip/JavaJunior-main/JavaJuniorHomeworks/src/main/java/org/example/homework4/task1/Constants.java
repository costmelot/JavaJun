package org.example.homework4.task1;

public class Constants {
    public static final String BOOK_TABLE = "book";
    public static final String BOOKS_ID = "idbooks";
    public static final String BOOK_NAME = "name";
    public static final String AUTHOR_NAME = "author";

}
