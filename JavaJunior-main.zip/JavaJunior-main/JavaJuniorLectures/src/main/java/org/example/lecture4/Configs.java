package org.example.lecture4;

public class Configs {
    protected static String dbHost = "localhost";
    protected static String dbPort = "3306";
    protected static String dbUser = "root";
    protected static String dbPass = "12345";
    protected static String dbName = "java_junior";
}
