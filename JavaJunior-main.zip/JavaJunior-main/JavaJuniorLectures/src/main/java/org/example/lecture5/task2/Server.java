package org.example.lecture5.task2;public class Server {
}
