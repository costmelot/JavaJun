package org.example.lecture4;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        //Db.con();
        //Db.con2();
        Db.conHib();
    }
}
