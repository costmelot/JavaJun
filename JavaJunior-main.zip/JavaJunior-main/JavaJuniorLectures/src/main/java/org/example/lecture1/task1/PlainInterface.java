package org.example.lecture1.task1;
@FunctionalInterface
public interface PlainInterface {
    int action(int x, int y);
}
